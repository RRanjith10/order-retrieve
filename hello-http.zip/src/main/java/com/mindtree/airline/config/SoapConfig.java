package com.mindtree.airline.config;

import javax.xml.bind.PropertyException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class SoapConfig {

	private String scanPackage = "com.ndc.orderCancel";


	@Bean
	public Jaxb2Marshaller marshaller() throws PropertyException {
		Jaxb2Marshaller jaxbMarshaller = new Jaxb2Marshaller();
		jaxbMarshaller.setPackagesToScan(scanPackage);
		return jaxbMarshaller;
	}
}