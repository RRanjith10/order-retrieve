package com.mindtree.airline.client;

import java.io.IOException;

import javax.xml.bind.PropertyException;
import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.transport.context.TransportContext;
import org.springframework.ws.transport.context.TransportContextHolder;
import org.springframework.ws.transport.http.HttpUrlConnection;

import com.mindtree.airline.config.SoapConfig;
import com.ndc.orderCancel.OrderCancelRQ;
import com.ndc.orderCancel.OrderCancelRS;
import com.ndc.orderCancel.OrderReshopRQ;
import com.ndc.orderCancel.OrderReshopRS;
import com.ndc.orderCancel.OrderRetrieveRQ;
import com.ndc.orderCancel.OrderViewRS;


@Service
public class SoapClient {

	private static final Logger logger = LoggerFactory.getLogger(SoapClient.class);

	private static final String retrieveURL = "https://test.api.ba.com/selling-distribution/OrderRetrieve/17.2/V1";

	private static final String reshopURL = "https://test.api.ba.com/selling-distribution/OrderReshop/17.2/V1";
	
	private static final String cancelURL = "https://test.api.ba.com/selling-distribution/OrderCancel/17.2/V1";

	private static final String clientKeyHeader = "Client-key";

	private static final String clinetKeyValue = "qy99c83f3qtyn6qur8daf8yf";

	private static final String retrieveSoapAction = "OrderRetrieve17_2_V1";
	
	private static final String reshopSoapAction = "OrderReshop17_2_V1";
	
	private static final String cancelSoapAction = "OrderCancel17_2_V1";
	
	SoapConfig soapconfig = new SoapConfig();

	public OrderViewRS getPnrDetails(OrderRetrieveRQ req) throws PropertyException {
		OrderViewRS res = new OrderViewRS();
		WebServiceTemplate template = new WebServiceTemplate(soapconfig.marshaller());

		try {
			res = (OrderViewRS) template.marshalSendAndReceive(retrieveURL, req, new WebServiceMessageCallback() {
				@Override
				public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
					((SoapMessage) message).setSoapAction(retrieveSoapAction);

					TransportContext context = TransportContextHolder.getTransportContext();
					HttpUrlConnection connection = (HttpUrlConnection) context.getConnection();
					connection.addRequestHeader(clientKeyHeader, clinetKeyValue);
				}
			});
		} catch (Exception e) {
			logger.error("error during marshalSendAndReceive of getPnrDetails", e);
		}
		return res;
	}

	public OrderReshopRS getReshopDetails(OrderReshopRQ req) throws PropertyException {
		OrderReshopRS res = new OrderReshopRS();
		WebServiceTemplate template = new WebServiceTemplate(soapconfig.marshaller());

		try {
			res = (OrderReshopRS) template.marshalSendAndReceive(reshopURL, req, new WebServiceMessageCallback() {
				@Override
				public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
					((SoapMessage) message).setSoapAction(reshopSoapAction);

					TransportContext context = TransportContextHolder.getTransportContext();
					HttpUrlConnection connection = (HttpUrlConnection) context.getConnection();
					connection.addRequestHeader(clientKeyHeader, clinetKeyValue);
				}
			});
		} catch (Exception e) {
			logger.error("error during marshalSendAndReceive of getRefundQuote", e);
		}
		return res;
	}
	
	public OrderCancelRS orderCancel(OrderCancelRQ req) throws PropertyException {
		OrderCancelRS res = new OrderCancelRS();
		WebServiceTemplate template = new WebServiceTemplate(soapconfig.marshaller());

		try {
			res = (OrderCancelRS) template.marshalSendAndReceive(cancelURL, req, new WebServiceMessageCallback() {
				@Override
				public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
					((SoapMessage) message).setSoapAction(cancelSoapAction);

					TransportContext context = TransportContextHolder.getTransportContext();
					HttpUrlConnection connection = (HttpUrlConnection) context.getConnection();
					connection.addRequestHeader(clientKeyHeader, clinetKeyValue);
				}
			});
		} catch (Exception e) {
			logger.error("error during marshalSendAndReceive of orderCancel", e);
		}
		return res;
	}
}